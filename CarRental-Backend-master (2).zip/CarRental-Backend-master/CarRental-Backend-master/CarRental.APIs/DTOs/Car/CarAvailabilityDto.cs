﻿namespace CarRental.APIs.DTOs.Car
{
    public class CarAvailabilityDto
    {
        public bool IsAvailable { get; set; }
    }
}

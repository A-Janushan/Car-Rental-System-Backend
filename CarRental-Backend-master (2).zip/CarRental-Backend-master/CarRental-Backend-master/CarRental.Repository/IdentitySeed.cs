﻿using CarRental.Core.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRental.Repository
{
    public static class IdentitySeed
    {
        public static async Task SeedUserAsync(IServiceProvider serviceProvider)
        {
            var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            var userManager = serviceProvider.GetRequiredService<UserManager<ApplicationUser>>();


            string[] roleNames = { "Admin", "User" };

            IdentityResult roleResult;

            foreach (var role in roleNames)
            {
                var roleExists = await roleManager.RoleExistsAsync(role);

                if (!roleExists)
                    roleResult = await roleManager.CreateAsync(new IdentityRole(role));
            }

            string email = "kajakajaa42@gmail.com";
            string password = "Kaja@2004";


            if (userManager.FindByEmailAsync(email).Result == null)
            {
                ApplicationUser user = new ApplicationUser()
                {
                    ImageProfileURl = "",
                    FName = "kajalaksan",
                    LName = "uthayachchandran",
                    Address = "jaffna",
                    DrivingLicURl = "",
                    NationalIdURl = "",
                    Email = "kajakajaa42@gmail.com",
                    DOB = new DateTime(2004, 1, 3),
                    UserName = "kaja",
                    PhoneNumber = "0761181969",
                };

                IdentityResult result = userManager.CreateAsync(user, password).Result;

                if (result.Succeeded)
                {
                    userManager.AddToRoleAsync(user, role: "Admin").Wait();
                }
            }
        }

    }
}

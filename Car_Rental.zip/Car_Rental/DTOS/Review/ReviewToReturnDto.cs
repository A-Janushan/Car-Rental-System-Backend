﻿namespace Car_Rental.DTOS.Review
{
    public class ReviewToReturnDto
    {
        public int? Rating { get; set; }
        public string? Comment { get; set; }
        public string? UserName { get; set; }
    }
}

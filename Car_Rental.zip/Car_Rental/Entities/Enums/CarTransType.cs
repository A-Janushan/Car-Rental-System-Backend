﻿namespace Car_Rental.Entities.Enums
{
    public enum CarTransType
    {
        Manual,
        Automatic
    }
}

﻿namespace Car_Rental.Entities
{
    public class Token
    {
        public string token { get; set; }
    }
}

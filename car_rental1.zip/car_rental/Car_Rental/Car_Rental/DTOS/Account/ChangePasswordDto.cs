﻿namespace Car_Rental.DTOS.Account
{
    public class ChangePasswordDTO
    {
    }
}

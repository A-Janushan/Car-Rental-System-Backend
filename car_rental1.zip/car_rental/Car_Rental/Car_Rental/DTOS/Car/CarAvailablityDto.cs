﻿namespace Car_Rental.DTOS.Car
{
    public class CarAvailablityDto
    {
    }
}

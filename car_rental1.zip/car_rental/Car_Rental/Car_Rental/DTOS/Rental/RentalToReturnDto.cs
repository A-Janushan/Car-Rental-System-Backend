﻿namespace Car_Rental.DTOS.Rental
{
    public class RentalToReturnDto
    {
    }
}

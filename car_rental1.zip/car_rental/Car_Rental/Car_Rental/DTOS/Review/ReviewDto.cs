﻿namespace Car_Rental.DTOS.Review
{
    public class ReviewDto
    {
    }
}

﻿namespace Car_Rental.DTOS.Review
{
    public class ReviewToReturnDto
    {
    }
}

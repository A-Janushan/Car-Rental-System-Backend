﻿namespace Car_Rental.Data
{
    public class CarRentalContext
    {
    }
}

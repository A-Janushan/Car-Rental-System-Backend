﻿namespace Car_Rental.Entities
{
    public class ApplicationUser
    {
        public string FName {  get; set; }
        public string LName { get; set; }
        public string Address { get; set; }
        public DateTime DOB { get; set; }

        //For Owner
        public  ICollection<Car>? Cars { get; set; }
        public ICollection<Rental>? Rentals { get; set; }


    }
}

﻿namespace Car_Rental.Entities.Enums
{
    public class RentalStatus
    {
    }
}

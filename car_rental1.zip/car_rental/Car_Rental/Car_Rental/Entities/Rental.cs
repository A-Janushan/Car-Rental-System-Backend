﻿namespace Car_Rental.Entities
{
    public class Rental
    {
    }
}

﻿namespace Car_Rental.Entities
{
    public class Review
    {
    }
}

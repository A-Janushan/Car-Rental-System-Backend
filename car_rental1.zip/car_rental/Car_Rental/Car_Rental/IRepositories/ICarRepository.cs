﻿namespace Car_Rental.Repositories
{
    public interface ICarRepository
    {
    }
}

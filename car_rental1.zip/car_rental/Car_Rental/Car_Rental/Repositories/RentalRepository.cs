﻿namespace Car_Rental.Repositories
{
    public class RentalRepository
    {
    }
}
